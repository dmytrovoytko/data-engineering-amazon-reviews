if 'condition' not in globals():
    from mage_ai.data_preparation.decorators import condition


@condition
def evaluate_condition(*args, **kwargs) -> bool:
    table_name = kwargs.get('table_name')
    return table_name == 'meta'
    

