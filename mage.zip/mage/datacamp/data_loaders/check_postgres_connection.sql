-- Docs: https://docs.mage.ai/guides/sql-blocks
SELECT 1;