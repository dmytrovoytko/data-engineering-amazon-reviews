from mage_ai.io.file import FileIO
if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import pandas as pd
import json
from pathlib import Path

from datacamp.utils import external_script

@data_loader
def load_data_from_file(*args, **kwargs):
    """
    Template for loading data from filesystem.
    Load data from 1 file or multiple file directories.

    For multiple directories, use the following:
        FileIO().load(file_directories=['dir_1', 'dir_2'])

    Docs: https://docs.mage.ai/design/data-loading#fileio
    """
    data_path = 'data/'
    # print(kwargs) 
    # kwargs['configuration'].get('import_file') #'meta_Digital_Music.jsonl'
    file_name = kwargs['file_name']
    table_name = kwargs['table_name']
    jsonl_name = data_path+file_name
    export_file_name = table_name+'_'
    # if table_name=='meta':
    #     selected_columns = ['parent_asin','title','main_category','average_rating','rating_number']
    # else:
    #     selected_columns = ['parent_asin','verified_purchase', 'rating', 'helpful_vote', 'user_id', 
    #                         'review_date',
    #                         ]

    # reducing memory consumption by setting explicit dtypes 
    dtypes = external_script.get_dtypes(table_name)
    # reducing unnecessary data from original file to process selected columns only 
    selected_columns = external_script.get_selected_columns(table_name)
    # for fixing incorrect main_category
    category_transformation = external_script.get_category_transformation(table_name, file_name)


    if (not Path(jsonl_name).is_file()) and jsonl_name.endswith('.gz'):
        # file unpacked?
        jsonl_name = jsonl_name[:-3]
    # print(selected_columns)
    # return selected_columns
    chunks = pd.read_json(jsonl_name, lines=True, chunksize=100000, dtype=dtypes)
    i = 0
    export_list = []
    for chunk in chunks:
        i += 1

        try:
            # print(type(chunk))
            df = chunk
            print(f'Chunk {i:02d}...{table_name}')
            if table_name=='reviews':
                df.columns = df.columns.str.replace('timestamp', 'review_date')

            df = df[selected_columns]
            external_script.transform1(df)
            file_name = data_path+export_file_name+f'{i:02d}.parquet'
            df.to_parquet(file_name, index=False)
            export_list.append(file_name)
        except Exception as e:
            print('Error', e)
            return None

    # return FileIO().load(filepath)
    return pd.DataFrame(export_list, columns=['file_name'])

@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'
