from mage_ai.orchestration.triggers.api import trigger_pipeline
if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter


@data_exporter
def trigger(df, *args, **kwargs):
    """
    Trigger another pipeline to run.

    Documentation: https://docs.mage.ai/orchestration/triggers/trigger-pipeline
    """
    rows_number = df.shape[0] 
    print(f'Processing {rows_number} dataset files...')

    for i in range(rows_number):
        table_name = df.at[i,'table_name']
        file_name = df.at[i,'file_name']
        trigger_pipeline(
            'process_datafile',        # Required: enter the UUID of the pipeline to trigger
            variables={'table_name': table_name,
                        'file_name': file_name
                    },           # Optional: runtime variables for the pipeline
            check_status=True,     # Optional: poll and check the status of the triggered pipeline
            error_on_failure=True, # Optional: if triggered pipeline fails, raise an exception
            poll_interval=60,       # Optional: check the status of triggered pipeline every N seconds
            poll_timeout=3600,      # Optional: raise an exception after N seconds
            verbose=True,           # Optional: print status of triggered pipeline run
        )
