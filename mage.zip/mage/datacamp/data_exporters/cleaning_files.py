from mage_ai.io.file import FileIO
from pandas import DataFrame

from pathlib import Path

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter


@data_exporter
def export_data_to_file(df: DataFrame, **kwargs) -> None:

    # after successful loading it would be good to clean those transitional files (csv/parquet)
    for i in range(df.shape[0]):
        file_name = df.at[i, 'file_name']
        try:
            Path(file_name).unlink()
        except Exception as e:
            print('Error deleting file', file_name, e)
            return False

    return True
