from mage_ai.settings.repo import get_repo_path
from mage_ai.io.config import ConfigFileLoader
from mage_ai.io.postgres import Postgres
from pandas import DataFrame
from os import path

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

import pandas as pd
from datacamp.utils import external_script
from sqlalchemy import create_engine


@data_exporter
def export_data_to_postgres(df: DataFrame, **kwargs) -> None:
    """
    Template for exporting data to a PostgreSQL database.
    Specify your configuration settings in 'io_config.yaml'.

    Docs: https://docs.mage.ai/design/data-loading#postgresql
    """

    
    table_name = kwargs['table_name']
    schema_name = 'public' # mage3 magic'amzn-'+table_name
    config_path = path.join(get_repo_path(), 'io_config.yaml')
    config_profile = 'dev'


    # import os
    # print(os.getenv("POSTGRES_HOST"), os.getenv("POSTGRES_DBNAME"), os.getenv("POSTGRES_DB"), os.getenv("POSTGRES_USER"), os.getenv("POSTGRES_PASSWORD"))
    # # print(df.head)

    # host = os.getenv("POSTGRES_HOST") # '172.17.0.2'
    # port=os.getenv("POSTGRES_PORT") # 5432
    # db=os.getenv("POSTGRES_DBNAME") #'amzn_reviews'
    # user=os.getenv("POSTGRES_USER")
    # password=os.getenv("POSTGRES_PASSWORD")
    # print(f'Connecting to PostgreSQL: {host}:{port}/{db}...')
    # try:
    #     engine = create_engine(f'postgresql://{user}:{password}@{host}:{port}/{db}')
    #     print('Connect', engine)
    # except Exception as e:
    #     print('PostgreSQL connection failed. Ingestion stopped.\n', e)
    #     return

    # print(df.head)
    with Postgres.with_config(ConfigFileLoader(config_path, config_profile)) as loader:
        for i in range(df.shape[0]):
            file_name = df.at[i, 'file_name']
            df_data = pd.read_parquet(file_name)
            # print(df_data.shape[0],df_data.head())
            mode = 'append' # 'replace' if i==0 else 'append'
            # if i==0:
            #     try:
            #         df_data.head(n=0).to_sql(name=table_name, con=engine, if_exists='replace')
            #         # print('Success')
            #     except Exception as e:
            #         print('Writing to Postgress error:', e)
            print(i, file_name, mode, df_data.shape[0])

            loader.export(
                df_data,
                schema_name,
                table_name,
                index=False,  # Specifies whether to include index in exported table
                if_exists=mode,  # Specify resolution policy if table name already exists
            )
            print(f' File {file_name} loaded successfully.', mode)
        # try:
        #     df_data.to_sql(name=table_name, con=engine, if_exists='append')
        #     print(f' File {file_name} loaded successfully.')
        # except Exception as e:
        #     print('Appending chunk {i} to PostgreSQL table failed. Ingestion stopped.\n',e)
        #     print(df_data.head())
        #     return


    # external_script.post_export(df)
    return df